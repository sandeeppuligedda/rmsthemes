<!DOCTYPE html>
<html lang="en-US">
<head>
				
			<meta property="og:url" content="https://sagen.qodeinteractive.com/xmlrpc.php"/>
			<meta property="og:type" content="article"/>
			<meta property="og:title" content="Sagen"/>
			<meta property="og:description" content="Single Property and Apartment Complex Theme"/>
			<meta property="og:image" content="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/open_graph.jpg"/>
		
		
		<meta charset="UTF-8"/>
		<link rel="profile" href="http://gmpg.org/xfn/11"/>
		
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
		<title>Page not found &#8211; Sagen</title>
<meta name='robots' content='max-image-preview:large' />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<!-- End Google Tag Manager for WordPress by gtm4wp.com --><link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//static.zdassets.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Sagen &raquo; Feed" href="https://sagen.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Sagen &raquo; Comments Feed" href="https://sagen.qodeinteractive.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/sagen.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.4"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://sagen.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/css/blocks/style.css?ver=3.6.7' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='image-map-pro-dist-css-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/image-map-pro-wordpress/css/image-map-pro.min.css?ver=5.1.6' type='text/css' media='' />
<link rel='stylesheet' id='rabbit_css-css'  href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.0.9' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='ppress-frontend-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/css/frontend.min.css?ver=3.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-flatpickr-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.css?ver=3.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='ppress-select2-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-default-style-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/style.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-modules-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/modules.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-dripicons-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/dripicons/dripicons.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_elegant-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/elegant-icons/style.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-font_awesome-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-ion_icons-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/ion-icons/css/ionicons.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linea_icons-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/linea-icons/style.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-linear_icons-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/linear-icons/style.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='qodef-simple_line_icons-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='https://sagen.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.16' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='https://sagen.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-woo-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/woocommerce.min.css?ver=5.8.4' type='text/css' media='all' />
<style id='sagen-select-woo-inline-css' type='text/css'>
@media only screen and (max-width: 1024px) {.error404 .qodef-title-holder, .error404 .qodef-title-holder .qodef-title-wrapper { height: px !important;}}
</style>
<link rel='stylesheet' id='sagen-select-woo-responsive-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/woocommerce-responsive.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-style-dynamic-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/style_dynamic.css?ver=1577266622' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-modules-responsive-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/modules-responsive.min.css?ver=5.8.4' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-style-dynamic-responsive-css'  href='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/css/style_dynamic_responsive.css?ver=1577266622' type='text/css' media='all' />
<link rel='stylesheet' id='sagen-select-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Oswald%3A400%2C700%7CPlayfair+Display%3A400%2C700&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->
<link rel='stylesheet' id='qode-zendesk-chat-css'  href='https://sagen.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css?ver=5.8.4' type='text/css' media='all' />
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/revolution.tools.min.js?ver=6.0' id='tp-tools-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.0.9' id='revmin-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/sagen.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.6.7' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.js?ver=5.8.4' id='ppress-flatpickr-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.js?ver=5.8.4' id='ppress-select2-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.13.1' id='gtm4wp-form-move-tracker-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.0.5' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://sagen.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://sagen.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://sagen.qodeinteractive.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.4" />
<meta name="generator" content="WooCommerce 3.6.7" />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M4XZBMN');//]]>
</script>
<!-- End Google Tag Manager -->
<!-- End Google Tag Manager for WordPress by gtm4wp.com -->	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.0.9 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://sagen.qodeinteractive.com/wp-content/uploads/2019/07/cropped-Favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://sagen.qodeinteractive.com/wp-content/uploads/2019/07/cropped-Favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://sagen.qodeinteractive.com/wp-content/uploads/2019/07/cropped-Favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://sagen.qodeinteractive.com/wp-content/uploads/2019/07/cropped-Favicon-270x270.png" />
<script type="text/javascript">function setREVStartSize(a){try{var b,c=document.getElementById(a.c).parentNode.offsetWidth;if(c=0===c||isNaN(c)?window.innerWidth:c,a.tabw=void 0===a.tabw?0:parseInt(a.tabw),a.thumbw=void 0===a.thumbw?0:parseInt(a.thumbw),a.tabh=void 0===a.tabh?0:parseInt(a.tabh),a.thumbh=void 0===a.thumbh?0:parseInt(a.thumbh),a.tabhide=void 0===a.tabhide?0:parseInt(a.tabhide),a.thumbhide=void 0===a.thumbhide?0:parseInt(a.thumbhide),a.mh=void 0===a.mh||""==a.mh?0:a.mh,"fullscreen"===a.layout||"fullscreen"===a.l)b=Math.max(a.mh,window.innerHeight);else{for(var d in a.gw=Array.isArray(a.gw)?a.gw:[a.gw],a.rl)(void 0===a.gw[d]||0===a.gw[d])&&(a.gw[d]=a.gw[d-1]);for(var d in a.gh=void 0===a.el||""===a.el||Array.isArray(a.el)&&0==a.el.length?a.gh:a.el,a.gh=Array.isArray(a.gh)?a.gh:[a.gh],a.rl)(void 0===a.gh[d]||0===a.gh[d])&&(a.gh[d]=a.gh[d-1]);var e,f=Array(a.rl.length),g=0;for(var d in a.tabw=a.tabhide>=c?0:a.tabw,a.thumbw=a.thumbhide>=c?0:a.thumbw,a.tabh=a.tabhide>=c?0:a.tabh,a.thumbh=a.thumbhide>=c?0:a.thumbh,a.rl)f[d]=a.rl[d]<window.innerWidth?0:a.rl[d];for(var d in e=f[0],f)e>f[d]&&0<f[d]&&(e=f[d],g=d);var h=c>a.gw[g]+a.tabw+a.thumbw?1:(c-(a.tabw+a.thumbw))/a.gw[g];b=a.gh[g]*h+(a.tabh+a.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(a.c).height=b,window.rs_init_css.innerHTML+="#"+a.c+"_wrapper { height: "+b+"px }"}catch(a){console.log("Failure at Presize of Slider:"+a)}};</script>
		<style type="text/css" id="wp-custom-css">
			@media only screen and (max-width: 1440px) {
	
.qodef-header-vertical .qodef-vertical-menu-area-inner {
	display: flex !important;
	flex-direction: column !important;
	justify-content: space-between !important;
}

.qodef-header-vertical .qodef-vertical-area-widget-holder {
	position: initial !important;
}
	
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 sagen-core-1.0 woocommerce-no-js sagen-ver-1.0 qodef-grid-1300 qodef-wide-dropdown-menu-content-in-grid qodef-enquire-menu-slide-from-right qodef-fixed-on-scroll qodef-dropdown-animate-height qodef-header-vertical-closed qodef-menu-area-shadow-disable qodef-menu-area-in-grid-shadow-disable qodef-menu-area-border-disable qodef-menu-area-in-grid-border-disable qodef-logo-area-border-disable qodef-logo-area-in-grid-border-disable qodef-header-vertical-shadow-disable qodef-header-vertical-border-disable qodef-side-menu-slide-from-right qodef-woocommerce-columns-3 qodef-woo-normal-space qodef-woo-pl-info-below-image qodef-woo-single-thumb-on-left-side qodef-woo-single-has-pretty-photo qodef-default-mobile-header qodef-sticky-up-mobile-header wpb-js-composer js-comp-ver-6.0.5 vc_responsive" itemscope itemtype="https://schema.org/WebPage">
    <div class="qodef-wrapper">
        <div class="qodef-wrapper-inner">
            
<div class="qodef-vertical-menu-area-overlay"></div>
<aside class="qodef-vertical-menu-area qodef-vertical-alignment-top">
    <div class="qodef-vertical-menu-area-inner">
		<a href="javascript:void(0)" class="qodef-vertical-area-opener qodef-vertical-area-opener-predefined">
			<span class="qodef-vertical-area-close-icon">
				<span aria-hidden="true" class="qodef-icon-font-elegant icon_close "></span>			</span>
			<span class="qodef-vertical-area-opener-icon">
				<span class="qodef-hm-lines"><span class="qodef-hm-line qodef-line-1"></span><span class="qodef-hm-line qodef-line-2"></span></span>			</span>
		</a>
        
	
	<div class="qodef-logo-wrapper">
		<a itemprop="url" href="https://sagen.qodeinteractive.com/" style="height: 38px;">
			<img itemprop="image" class="qodef-normal-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo.png"  alt="logo"/>
			<img itemprop="image" class="qodef-dark-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo.png"  alt="dark logo"/>			<img itemprop="image" class="qodef-light-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo_white.png"  alt="light logo"/>		</a>
	</div>


        <div class="qodef-vertical-menu-outer">
	<nav class="qodef-vertical-menu qodef-vertical-dropdown-below">
		<ul id="menu-vertical-menu-closed" class=""><li id="nav-menu-item-58" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Home</span></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-512" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://sagen.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Main Home</span></span></a></li>
	<li id="nav-menu-item-2438" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/apartment-complex/" class=""><span class="item_outer"><span class="item_text">Apartment Complex</span></span></a></li>
	<li id="nav-menu-item-2439" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/left-menu-home/" class=""><span class="item_outer"><span class="item_text">Left Menu Home</span></span></a></li>
	<li id="nav-menu-item-2436" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/properties-slider/" class=""><span class="item_outer"><span class="item_text">Properties Slider</span></span></a></li>
	<li id="nav-menu-item-2437" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/property-agency/" class=""><span class="item_outer"><span class="item_text">Property Agency</span></span></a></li>
	<li id="nav-menu-item-511" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/properties-home/" class=""><span class="item_outer"><span class="item_text">Properties Home</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-1662" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-1664" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
	<li id="nav-menu-item-2452" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-partners/" class=""><span class="item_outer"><span class="item_text">Our Partners</span></span></a></li>
	<li id="nav-menu-item-1661" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/get-in-touch/" class=""><span class="item_outer"><span class="item_text">Get In Touch</span></span></a></li>
	<li id="nav-menu-item-1663" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span></span></a></li>
	<li id="nav-menu-item-2453" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-team/" class=""><span class="item_outer"><span class="item_text">Our Team</span></span></a></li>
	<li id="nav-menu-item-2451" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-services/" class=""><span class="item_outer"><span class="item_text">Our Services</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-1103" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Property</span></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-1102" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/property-standard-list/" class=""><span class="item_outer"><span class="item_text">Standard List</span></span></a></li>
	<li id="nav-menu-item-2450" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/gallery-list-wide/" class=""><span class="item_outer"><span class="item_text">Gallery List Wide</span></span></a></li>
	<li id="nav-menu-item-1188" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/masonry/" class=""><span class="item_outer"><span class="item_text">Masonry List</span></span></a></li>
	<li id="nav-menu-item-1267" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/masonry-wide/" class=""><span class="item_outer"><span class="item_text">Masonry List Wide</span></span></a></li>
	<li id="nav-menu-item-2448" class="menu-item menu-item-type-post_type menu-item-object-property-item "><a href="https://sagen.qodeinteractive.com/property-item/mudoks-resident/" class=""><span class="item_outer"><span class="item_text">Custom Single No. 01</span></span></a></li>
	<li id="nav-menu-item-2449" class="menu-item menu-item-type-post_type menu-item-object-property-item "><a href="https://sagen.qodeinteractive.com/property-item/greenheart-metropolis/" class=""><span class="item_outer"><span class="item_text">Custom Single No. 02</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-1657" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="https://sagen.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span></span></a></li>
</ul>	</nav>
</div>

	    		    <div class="qodef-vertical-area-widget-holder">
			    			
			<a class="qodef-icon-widget-holder"  href="mailto:sagen@qodeinteractive.com" target="_self" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">sagen@qodeinteractive.com</span>			</a>
						
			<a class="qodef-icon-widget-holder"  href="https://www.google.com/maps/place/Amsterdam,+Netherlands/@52.34956,4.8915986,17z/data=!4m5!3m4!1s0x47c63fb5949a7755:0x6600fd4cb7c0af8d!8m2!3d52.3679843!4d4.9035614" target="_blank" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">184 Main Collins Street Victoria 8007</span>			</a>
			<div class="widget qodef-social-texts-group-widget ">					<a class="qodef-social-text-widget-holder" href="https://www.facebook.com/QodeInteractive/" target="_blank">
						fb					</a>
									<a class="qodef-social-text-widget-holder" href="https://twitter.com/QodeInteractive" target="_blank">
						tw					</a>
									<a class="qodef-social-text-widget-holder" href="https://www.instagram.com/qodeinteractive/" target="_blank">
						in					</a>
				</div>		    </div>
	        </div>
	<div class="qodef-vertical-area-bottom-logo">
		<div class="qodef-vertical-area-bottom-logo-inner">
			
	
	<div class="qodef-logo-wrapper">
		<a itemprop="url" href="https://sagen.qodeinteractive.com/" style="height: 37px;">
			<img itemprop="image" class="qodef-normal-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo-vertical-closed.png"  alt="logo"/>
			<img itemprop="image" class="qodef-dark-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo.png"  alt="dark logo"/>			<img itemprop="image" class="qodef-light-logo" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo_white.png"  alt="light logo"/>		</a>
	</div>

		</div>
					<div class="qodef-vertical-area-bottom-widget-holder">
							<a class="qodef-enquire-menu-button-opener qodef-icon-has-hover qodef-enquire-menu-button-opener-predefined" href="javascript:void(0)" >
								<span class="qodef-enquire-menu-text">
					MAKE AN ENQUIRY	            </span>
			</a>
					</div>
			</div>
</aside>


<header class="qodef-mobile-header">
		
	<div class="qodef-mobile-header-inner">
		<div class="qodef-mobile-header-holder">
			            <div class="qodef-grid">
                            <div class="qodef-vertical-align-containers">
                    <div class="qodef-position-left"><!--
                     --><div class="qodef-position-left-inner">
                            
<div class="qodef-mobile-logo-wrapper">
	<a itemprop="url" href="https://sagen.qodeinteractive.com/" style="height: 38px">
		<img itemprop="image" src="https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/img/logo.png"  alt="Mobile Logo"/>
	</a>
</div>

                        </div>
                    </div>
                    <div class="qodef-position-right"><!--
                     --><div class="qodef-position-right-inner">
                                                                                        <div class="qodef-mobile-menu-opener qodef-mobile-menu-opener-predefined">
                                    <a href="javascript:void(0)">
                                                                                <span class="qodef-mobile-menu-icon">
                                            <span class="qodef-hm-lines"><span class="qodef-hm-line qodef-line-1"></span><span class="qodef-hm-line qodef-line-2"></span></span>                                        </span>
                                    </a>
                                </div>
                                                    </div>
                    </div>
				</div>
                        </div>
		    		</div>
		
	<nav class="qodef-mobile-nav" role="navigation" aria-label="Mobile Menu">
		<div class="qodef-grid">
			<ul id="menu-main" class=""><li id="mobile-menu-item-513" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Home</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-518" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://sagen.qodeinteractive.com/" class=""><span>Main Home</span></a></li>
	<li id="mobile-menu-item-996" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/apartment-complex/" class=""><span>Apartment Complex</span></a></li>
	<li id="mobile-menu-item-641" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/left-menu-home/" class=""><span>Left Menu Home</span></a></li>
	<li id="mobile-menu-item-1791" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/properties-slider/" class=""><span>Properties Slider</span></a></li>
	<li id="mobile-menu-item-913" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/property-agency/" class=""><span>Property Agency</span></a></li>
	<li id="mobile-menu-item-519" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/properties-home/" class=""><span>Properties Home</span></a></li>
	<li id="mobile-menu-item-2148" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/landing/" class=""><span>Landing</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-514" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Pages</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-1421" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
	<li id="mobile-menu-item-1418" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-partners/" class=""><span>Our Partners</span></a></li>
	<li id="mobile-menu-item-1419" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/get-in-touch/" class=""><span>Get In Touch</span></a></li>
	<li id="mobile-menu-item-1420" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/contact-us/" class=""><span>Contact Us</span></a></li>
	<li id="mobile-menu-item-1417" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-team/" class=""><span>Our Team</span></a></li>
	<li id="mobile-menu-item-1416" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/our-services/" class=""><span>Our Services</span></a></li>
	<li id="mobile-menu-item-1423" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://sagen.qodeinteractive.com/error-page" class=""><span>404 Error Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-515" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Blog</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-929" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/right-sidebar/" class=""><span>Right Sidebar</span></a></li>
	<li id="mobile-menu-item-928" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/left-sidebar/" class=""><span>Left Sidebar</span></a></li>
	<li id="mobile-menu-item-926" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/blog-masonry/" class=""><span>Blog Masonry</span></a></li>
	<li id="mobile-menu-item-927" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/no-sidebar/" class=""><span>No Sidebar</span></a></li>
	<li id="mobile-menu-item-931" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Singles</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-948" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/warm-hygge/" class=""><span>Standard</span></a></li>
		<li id="mobile-menu-item-952" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/resort-retreat/" class=""><span>Gallery</span></a></li>
		<li id="mobile-menu-item-950" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/now-in-its-fifth-generation-of-owners-the-historic-hotel-bar-has-aptly-been-given-the-family-name/" class=""><span>Link</span></a></li>
		<li id="mobile-menu-item-949" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/find-the-better-way/" class=""><span>Quote</span></a></li>
		<li id="mobile-menu-item-953" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/summer-view/" class=""><span>Video</span></a></li>
		<li id="mobile-menu-item-954" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/metropolis-podcast/" class=""><span>Audio</span></a></li>
		<li id="mobile-menu-item-951" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://sagen.qodeinteractive.com/belmond-cadogan-hotel/" class=""><span>No Sidebar</span></a></li>
	</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-516" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Shop</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-522" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop-list/" class=""><span>Product List</span></a></li>
	<li id="mobile-menu-item-521" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://sagen.qodeinteractive.com/product/amos-plate/" class=""><span>Product Single</span></a></li>
	<li id="mobile-menu-item-2908" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Layouts</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-528" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop/two-columns/" class=""><span>Two Columns</span></a></li>
		<li id="mobile-menu-item-527" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop/three-columns/" class=""><span>Three Columns</span></a></li>
		<li id="mobile-menu-item-526" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop/four-columns/" class=""><span>Four Columns</span></a></li>
		<li id="mobile-menu-item-525" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop/four-columns-wide/" class=""><span>Four Columns Wide</span></a></li>
		<li id="mobile-menu-item-524" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/shop/five-columns-wide/" class=""><span>Five Columns Wide</span></a></li>
	</ul>
</li>
	<li id="mobile-menu-item-529" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" qodef-mobile-no-link"><span>Pages</span></a><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-530" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/my-account/" class=""><span>My Account</span></a></li>
		<li id="mobile-menu-item-532" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/cart/" class=""><span>Cart</span></a></li>
		<li id="mobile-menu-item-531" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/checkout/" class=""><span>Checkout</span></a></li>
	</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-517" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Property</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-1297" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Singles</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-1299" class="menu-item menu-item-type-post_type menu-item-object-property-item "><a href="https://sagen.qodeinteractive.com/property-item/mudoks-resident/" class=""><span>Custom Single No. 1</span></a></li>
		<li id="mobile-menu-item-1298" class="menu-item menu-item-type-post_type menu-item-object-property-item "><a href="https://sagen.qodeinteractive.com/property-item/greenheart-metropolis/" class=""><span>Custom Single No. 2</span></a></li>
	</ul>
</li>
	<li id="mobile-menu-item-1001" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Lists</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-1000" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/property-standard-list/" class=""><span>Standard List</span></a></li>
		<li id="mobile-menu-item-1270" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/gallery-list-in-grid/" class=""><span>Gallery List in Grid</span></a></li>
		<li id="mobile-menu-item-2454" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/gallery-list-wide/" class=""><span>Gallery List Wide</span></a></li>
		<li id="mobile-menu-item-1269" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/masonry/" class=""><span>Masonry</span></a></li>
		<li id="mobile-menu-item-1268" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/masonry-wide/" class=""><span>Masonry List Wide</span></a></li>
	</ul>
</li>
	<li id="mobile-menu-item-1300" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Layouts</span></h6><span class="mobile_arrow"><i class="qodef-sub-arrow qodef-icon-ion-icon ion-ios-arrow-forward"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-1938" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/two-col-grid/" class=""><span>Two Col. Grid</span></a></li>
		<li id="mobile-menu-item-1940" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/three-col-grid/" class=""><span>Three Col. Grid</span></a></li>
		<li id="mobile-menu-item-1939" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/three-col-wide/" class=""><span>Three Col. Wide</span></a></li>
		<li id="mobile-menu-item-1942" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/four-col-grid/" class=""><span>Four Col. Grid</span></a></li>
		<li id="mobile-menu-item-1941" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/four-col-wide/" class=""><span>Four Col. Wide</span></a></li>
		<li id="mobile-menu-item-1943" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://sagen.qodeinteractive.com/five-col-wide/" class=""><span>Five Col. Wide</span></a></li>
	</ul>
</li>
</ul>
</li>
</ul>		</div>
	</nav>

	</div>
	
	</header>

			<a id='qodef-back-to-top' href='#'>

	                <span class="qodef-back-to-top-text">
	                    Back to top
						</span>


			</a>
			        
            <div class="qodef-content" style="margin-top: -74px">
                <div class="qodef-content-inner">				<div class="qodef-page-not-found">
										
					<h1 class="qodef-404-title">
						Error Page					</h1>
					
					<p class="qodef-404-text">
						Looks like something went completly wrong! Don’t worry, it can happen to the best of us.					</p>

					<a itemprop="url" href="https://sagen.qodeinteractive.com/" target="_self"  class="qodef-btn qodef-btn-medium qodef-btn-outline qodef-btn-icon"  >
	<span aria-hidden="true" class="qodef-icon-font-elegant arrow_left " ></span>	<span class="qodef-btn-svg">
		<svg x="0px" y="0px" viewBox="0 0 5.5 10.1" enable-background="new 0 0 5.5 10.1" >
				<path fill="#BBBBBB" d="M1.3,5.5L1.2,5.2C2.1,4.5,2.7,4.1,3,3.9c0.3-0.2,0.6-0.2,0.7-0.2c0.1,0,0.2,0,0.3,0.1S4.1,4,4.1,4.2
					c0,0.3-0.1,0.8-0.4,1.7L3.5,6.5c-0.3,1-0.4,1.6-0.4,1.9c0,0.1,0.1,0.2,0.2,0.2c0.1,0,0.4-0.2,1-0.6l0.2,0.3L3.2,9.1
					C2.8,9.3,2.6,9.4,2.4,9.5c-0.1,0-0.2,0.1-0.3,0.1c-0.1,0-0.3,0-0.3-0.1C1.7,9.3,1.7,9.2,1.7,8.9c0-0.3,0.1-0.7,0.2-1.1l0.4-1.4
					C2.4,5.7,2.5,5.3,2.5,5c0-0.1,0-0.2-0.1-0.2c-0.1,0-0.2,0-0.3,0.1C1.8,5.1,1.5,5.3,1.3,5.5z M3.2,2c0-0.3,0.1-0.5,0.2-0.7
					S3.8,1,4,1c0.2,0,0.3,0.1,0.5,0.2s0.2,0.3,0.2,0.5c0,0.3-0.1,0.5-0.2,0.7C4.3,2.5,4.1,2.6,3.8,2.6c-0.2,0-0.4-0.1-0.5-0.2
					C3.2,2.3,3.2,2.1,3.2,2z"/>
		</svg>
	</span>
	<span class="qodef-btn-text">Back to Home</span>
</a>					<div class="qodef-row-background-custom-holder"><div class="qodef-row-background-text-wrapper qodef-row-background-text-align-right">
							<div class="qodef-row-background-text-wrapper-inner" style="text-align:center;vertical-align:bottom;">
								<div class="qodef-row-background-text-1">404</div>
							</div>
						</div>
					</div>
					<div class="qodef-row-background-corner-holder bottom-right" style="height: 80%;"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<section class="qodef-enquire-menu">
	<a class="qodef-close-enquire-menu qodef-close-enquire-menu-predefined" href="#">
		<span class="qodef-hm-lines">
			<span class="qodef-hm-line qodef-line-1"></span>
			<span class="qodef-hm-line qodef-line-2"></span>
		</span>
	</a>
	<div id="text-4" class="widget qodef-enquirearea widget_text"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">MAKE A GENERAL ENQUIRY</h5></div>			<div class="textwidget"><p>Lorem ipsum dolor sit amet, consectetur adipis elit, sed do eiusmod tempor.</p>
</div>
		</div>			<div class="widget qodef-contact-form-7-widget  " >
								<div role="form" class="wpcf7" id="wpcf7-f11-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/xmlrpc.php#wpcf7-f11-o1" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="11" />
<input type="hidden" name="_wpcf7_version" value="5.5.1" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f11-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="qodef-grid-row qodef-grid-small-gutter">
<div class="qodef-grid-col-12"><span class="wpcf7-form-control-wrap qodef-mail"><input type="email" name="qodef-mail" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email*" /></span></div>
<div class="qodef-grid-col-12"><span class="wpcf7-form-control-wrap qodef-phone"><input type="text" name="qodef-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Phone*" /></span></div>
<div class="qodef-grid-col-12"><span class="wpcf7-form-control-wrap qodef-message"><input type="text" name="qodef-message" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Message" /></span></div>
</div>
<p><button type="submit" class="wpcf7-form-control wpcf7-submit qodef-btn qodef-btn-medium qodef-btn-outline"><span class="qodef-btn-text"><i class="qodef-icon-ion-icon ion-android-mail qodef-icon-element"></i> Send Us A Message</span></button></p>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div>			</div>
			<div class="widget qodef-separator-widget"><div class="qodef-separator-holder clearfix  qodef-separator-center qodef-separator-normal">
	<div class="qodef-separator" style="border-style: solid;margin-top: 20px"></div>
</div>
</div>			
			<a class="qodef-icon-widget-holder"  href="tel:58588999696" target="_self" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">+585 889 996 96</span>			</a>
						
			<a class="qodef-icon-widget-holder"  href="mailto:sagen@qodeinteractive.com" target="_self" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">sagen@qodeinteractive.com</span>			</a>
						
			<a class="qodef-icon-widget-holder"  href="https://www.google.com/maps/place/Amsterdam,+Netherlands/@52.34956,4.8915986,17z/data=!4m5!3m4!1s0x47c63fb5949a7755:0x6600fd4cb7c0af8d!8m2!3d52.3679843!4d4.9035614" target="_blank" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">184 Main Collins Street Victoria</span>			</a>
			<div class="widget qodef-social-texts-group-widget ">					<a class="qodef-social-text-widget-holder" href="https://www.facebook.com/QodeInteractive/" target="_blank">
						fb					</a>
									<a class="qodef-social-text-widget-holder" href="https://twitter.com/QodeInteractive" target="_blank">
						tw					</a>
									<a class="qodef-social-text-widget-holder" href="https://www.instagram.com/qodeinteractive/" target="_blank">
						in					</a>
				</div></section><section class="qodef-side-menu">
	<a class="qodef-close-side-menu qodef-close-side-menu-predefined" href="#">
		<span aria-hidden="true" class="qodef-icon-font-elegant icon_close "></span>	</a>
	<div id="media_image-4" class="widget qodef-sidearea widget_media_image"><a href="https://sagen.qodeinteractive.com"><img width="98" height="38" src="https://sagen.qodeinteractive.com/wp-content/uploads/2019/07/logo-side-area.png" class="image wp-image-2396  attachment-full size-full" alt="a" loading="lazy" style="max-width: 100%; height: auto;" /></a></div><div id="text-3" class="widget qodef-sidearea widget_text"><div class="qodef-widget-title-holder"><h5 class="qodef-widget-title">Get In Touch With Us Today</h5></div>			<div class="textwidget"><p>Welcome to Sagen, a modern platform perfect for showcasing your properties. </p>
</div>
		</div>			
			<a class="qodef-icon-widget-holder"  href="tel:58588999696" target="_self" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">+585 889 996 96</span>			</a>
						
			<a class="qodef-icon-widget-holder"  href="mailto:sagen@qodeinteractive.com" target="_self" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">sagen@qodeinteractive.com</span>			</a>
						
			<a class="qodef-icon-widget-holder"  href="https://www.google.com/maps/place/Amsterdam,+Netherlands/@52.34956,4.8915986,17z/data=!4m5!3m4!1s0x47c63fb5949a7755:0x6600fd4cb7c0af8d!8m2!3d52.3679843!4d4.9035614" target="_blank" >
								<span class="qodef-icon-text qodef-no-icon" style="font-size: 16px">184 Main Collins Street Victoria</span>			</a>
			<div class="widget qodef-social-texts-group-widget ">					<a class="qodef-social-text-widget-holder" href="https://www.facebook.com/QodeInteractive/" target="_blank">
						fb					</a>
									<a class="qodef-social-text-widget-holder" href="https://twitter.com/QodeInteractive" target="_blank">
						tw					</a>
									<a class="qodef-social-text-widget-holder" href="https://www.instagram.com/qodeinteractive/" target="_blank">
						in					</a>
				</div></section><div class="rbt-toolbar" data-theme="Sagen" data-featured="" data-button-position="50%" data-button-horizontal="right" data-button-alt="no" ></div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M4XZBMN"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/sagen.qodeinteractive.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.1' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/image-map-pro-wordpress/js/image-map-pro.min.js?ver=5.1.6' id='image-map-pro-dist-js-js'></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=5.8.4' id='rabbit_js-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.6.7' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_fb75ccf7954687746c8c973d6ada3741","fragment_name":"wc_fragments_fb75ccf7954687746c8c973d6ada3741","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.6.7' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='ppress-frontend-script-js-extra'>
/* <![CDATA[ */
var pp_ajax_form = {"ajaxurl":"https:\/\/sagen.qodeinteractive.com\/wp-admin\/admin-ajax.php","confirm_delete":"Are you sure?","deleting_text":"Deleting...","deleting_error":"An error occurred. Please try again.","nonce":"0b7d5a5512","disable_ajax_form":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/js/frontend.min.js?ver=3.2.0' id='ppress-frontend-script-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.12.1' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.16' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.8.4' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.8.4' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.appear.js?ver=5.8.4' id='appear-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/modernizr.min.js?ver=5.8.4' id='modernizr-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/hoverIntent.min.js?ver=1.10.1' id='hoverIntent-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.plugin.js?ver=5.8.4' id='jquery-plugin-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/owl.carousel.min.js?ver=5.8.4' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.waypoints.min.js?ver=5.8.4' id='waypoints-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/fluidvids.min.js?ver=5.8.4' id='fluidvids-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=5.8.4' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=5.8.4' id='scroll-to-plugin-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/parallax.min.js?ver=5.8.4' id='parallax-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.waitforimages.js?ver=5.8.4' id='waitforimages-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.prettyPhoto.js?ver=5.8.4' id='prettyphoto-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/jquery.easing.1.3.js?ver=5.8.4' id='jquery-easing-1.3-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.0.5' id='isotope-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/packery-mode.pkgd.min.js?ver=5.8.4' id='packery-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules/plugins/swiper.min.js?ver=5.8.4' id='swiper-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3' id='select2-js'></script>
<script type='text/javascript' src='//maps.googleapis.com/maps/api/js?key=AIzaSyDRW0y9pEz2w0HwYNUgE0KPPhMv-cw3iSI&#038;ver=5.8.4' id='sagen-select-google-map-api-js'></script>
<script type='text/javascript' id='sagen-select-modules-js-extra'>
/* <![CDATA[ */
var qodefGlobalVars = {"vars":{"qodefAddForAdminBar":0,"qodefElementAppearAmount":-100,"qodefAjaxUrl":"https:\/\/sagen.qodeinteractive.com\/wp-admin\/admin-ajax.php","sliderNavPrevArrow":"ion-ios-arrow-left","sliderNavNextArrow":"ion-ios-arrow-right","ppExpand":"Expand the image","ppNext":"Next","ppPrev":"Previous","ppClose":"Close","qodefStickyHeaderHeight":0,"qodefStickyHeaderTransparencyHeight":0,"qodefTopBarHeight":0,"qodefLogoAreaHeight":0,"qodefMenuAreaHeight":0,"qodefMobileHeaderHeight":74}};
var qodefPerPageVars = {"vars":{"qodefMobileHeaderHeight":74,"qodefStickyScrollAmount":0,"qodefHeaderTransparencyHeight":0,"qodefHeaderVerticalWidth":70}};
/* ]]> */
</script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/themes/sagen/assets/js/modules.min.js?ver=5.8.4' id='sagen-select-modules-js'></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&#038;ver=5.8.4" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no") {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script><script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-includes/js/wp-embed.min.js?ver=5.8.4' id='wp-embed-js'></script>
<script type='text/javascript' src='https://sagen.qodeinteractive.com/wp-content/plugins/sagen-core/shortcodes/image-map-gallery/assets/exclude_js/image-map-gallery.js?ver=5.8.4' id='sagen-core-imp-script-js'></script>
</body>
</html>